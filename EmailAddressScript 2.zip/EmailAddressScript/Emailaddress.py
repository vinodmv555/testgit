from tkinter import *
from tkinter.messagebox import *
import tkinter
from tkinter.filedialog import askopenfilename
import subprocess,json

def subprocess_cmd(command):
    process = subprocess.Popen(command,stdout=subprocess.PIPE, shell=True)
    proc_stdout = process.communicate()[0].strip()
    print(proc_stdout)


def show_answer():
    global v
    data = {}
    data['path']=v
    data['email']=requestor.get()

    # Passing varible input to Powershell script.
    with open('data.json', 'w') as outfile:
        json.dump(data, outfile)
            
    path.insert(0,v)
    blank.insert(0,"Script Running")
    tkinter.messagebox.showinfo('answer',"submitted")
    print(F"{requestor.get()}")
    subprocess_cmd('powershell.exe .\pow.ps1')

    blank.delete(0,END)
    blank.insert(0, "completed")
    
  
def import_csv_data():

    global v
    csv_file_path = askopenfilename()
    print(csv_file_path)
    v =csv_file_path
    # df = pd.read_csv(csv_file_path) 


main = Tk()
Label(main, text = "Enter Requester Email Address:").grid(row=0)

Button(main, text='Upload TXT File ', command=import_csv_data).grid(row=1, column=0, sticky=W, pady=4)

Label(main, text = "Result :").grid(row=5)


requestor = Entry(main)
path = Entry(main)
blank = Entry(main)
print(F"{requestor.get()}")

requestor.grid(row=0, column=1)
path.grid(row=1, column=1)
blank.grid(row=5, column=1)


Button(main, text='Quit', command=main.quit).grid(row=4, column=0, sticky=W, pady=4)
Button(main, text='SUBMIT', command=show_answer).grid(row=4, column=1, sticky=W, pady=4)

mainloop()